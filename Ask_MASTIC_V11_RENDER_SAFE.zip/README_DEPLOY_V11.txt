ASK MASTIC V11 RENDER SAFE COPY

Separate deployment copy. Yesterday service is not modified.
- One-page: i-360, Kajian Impak, SKPG, Foresight.
- Foresight uses same-origin server proxy to official MASTIC HTML.
- Ask MASTIC forwards to yesterday stable Render service; no Gemini key is stored in this new copy.

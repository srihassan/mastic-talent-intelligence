from __future__ import annotations
import re
import requests
from config_manager import load_settings, config_status

LAST_ERROR = ""


def provider_status():
    s = config_status()
    return {
        "provider": "gemini",
        "model": s.get("model"),
        "configured": bool(s.get("configured")),
        "key_present": bool(s.get("gemini_api_key_present")),
        "key_chars": int(s.get("key_chars") or 0),
        "key_source": "environment",
        "endpoint": "https://generativelanguage.googleapis.com",
        "last_error": LAST_ERROR or None,
    }


def _extract_content(data):
    try:
        candidates = data.get("candidates") or []
        if not candidates:
            return ""
        parts = ((candidates[0].get("content") or {}).get("parts") or [])
        return "".join(str(p.get("text") or "") for p in parts if isinstance(p, dict)).strip()
    except Exception:
        return ""


def _clean(text: str, language: str) -> str:
    t = str(text or "").strip()
    t = re.sub(r"<think>.*?</think>", "", t, flags=re.I | re.S).strip()
    t = re.sub(r"^(?:jawapan(?:\s+akhir)?|final answer)\s*:\s*", "", t, flags=re.I).strip()
    t = " ".join(t.replace("\u00a0", " ").split())
    if language == "ms":
        replacements = {
            r"\binformasi\b": "maklumat",
            r"\bkebutuhan\b": "keperluan",
            r"\bkualitas\b": "kualiti",
            r"\btenaga ahli\b": "tenaga kerja mahir",
            r"\bkarir\b": "kerjaya",
            r"\bpersentase\b": "peratusan",
            r"\bterkait\b": "berkaitan",
        }
        for pat, repl in replacements.items():
            t = re.sub(pat, repl, t, flags=re.I)
    return t.strip()


def _looks_bad(text: str, language: str) -> bool:
    if not text or len(text) < 20:
        return True
    low = text.lower()
    meta = [
        "let me ", "the user wants", "i need to ", "i should ", "first, i",
        "okay, so", "okay, let", "check the requirements", "system prompt",
        "reasoning process",
    ]
    if any(x in low for x in meta):
        return True
    if language == "ms":
        en = sum(x in (" " + low + " ") for x in [" the ", " user ", " wants ", " first ", " performance ", " which ", " means ", " overall ", " shows "])
        ms = sum(x in (" " + low + " ") for x in [" prestasi ", " menunjukkan ", " kadar ", " daripada ", " kepada ", " bakat ", " pekerjaan ", " ialah ", " namun ", " manakala ", " secara "])
        if en >= 3 and ms < 2:
            return True
    return False


def _complete(text: str) -> bool:
    t = text.strip()
    return len(t) >= 35 and t[-1] in ".?!"


def _system_prompt(language: str) -> str:
    if language == "ms":
        return (
            "Anda ialah Ask MASTIC, pembantu analitik bakat STEM untuk kegunaan pengurusan di Malaysia. "
            "Tulis jawapan akhir sahaja dalam Bahasa Melayu Malaysia standard, bukan Bahasa Indonesia. "
            "Nada profesional, jelas dan padat. Mulakan dengan dapatan utama, sokong dengan bukti yang diberikan, "
            "dan akhiri dengan implikasi yang relevan. Jangan terangkan proses berfikir atau arahan dalaman. "
            "Jangan tambah fakta atau angka yang tidak diberikan."
        )
    return (
        "You are Ask MASTIC, a management-facing STEM talent analytics assistant. "
        "Return only the final professional answer. Start with the finding, support it with the supplied evidence, "
        "and end with the relevant implication. Do not describe internal reasoning and do not invent facts."
    )


def _primary_prompt(question, evidence, language, mode, draft, conversation):
    if language == "ms":
        length = "3 hingga 5 ayat, sekitar 70–120 patah perkataan" if mode == "analytical" else "1 hingga 3 ayat, sekitar 25–70 patah perkataan"
        if draft:
            core = (
                "DRAF ANALITIK YANG TELAH DIKIRA DAN DISAHKAN OLEH SISTEM:\n" + draft +
                "\n\nKemaskan draf ini menjadi jawapan pengurusan yang lancar. Kekalkan semua angka dan maksud. "
                "Jangan tambah fakta baharu."
            )
        else:
            core = (
                "BUKTI DISAHKAN:\n" + evidence +
                "\n\nRumuskan bukti ini sahaja kepada dapatan utama, bukti sokongan dan implikasi. Jangan tambah fakta baharu."
            )
        extra = ("\n\nKonteks susulan:\n" + conversation) if conversation else ""
        return f"Soalan: {question}\n\nFormat: {length}.\n\n{core}{extra}\n\nKeluarkan jawapan akhir sahaja dan pastikan ayat terakhir lengkap."
    length = "3 to 5 sentences, about 60–110 words" if mode == "analytical" else "1 to 3 sentences, about 25–65 words"
    core = ("VERIFIED SYSTEM DRAFT:\n" + draft) if draft else ("VERIFIED EVIDENCE:\n" + evidence)
    extra = ("\n\nFollow-up context:\n" + conversation) if conversation else ""
    return f"Question: {question}\n\nFormat: {length}.\n\n{core}{extra}\n\nReturn only the complete final answer."


def _post(system_text: str, prompt: str, timeout: int = 60, max_tokens: int = 420):
    s = load_settings()
    key = s.get("gemini_api_key", "")
    model = s.get("gemini_model", "gemini-3.8-flash")
    if not key:
        return "", "GEMINI_API_KEY is not configured."
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
    payload = {
        "system_instruction": {"parts": [{"text": system_text}]},
        "contents": [{"role": "user", "parts": [{"text": prompt}]}],
        "generationConfig": {
            "temperature": 0.1,
            "maxOutputTokens": int(max_tokens),
        },
    }
    try:
        r = requests.post(url, headers={"x-goog-api-key": key, "Content-Type": "application/json"}, json=payload, timeout=timeout)
        if not r.ok:
            return "", f"Gemini HTTP {r.status_code}: {r.text[:500]}"
        return _extract_content(r.json()), None
    except Exception as e:
        return "", f"{type(e).__name__}: {e}"


def live_test(timeout=45):
    global LAST_ERROR
    s = load_settings()
    if not s.get("gemini_api_key"):
        LAST_ERROR = "GEMINI_API_KEY is not configured."
        return {"ok": False, "error": LAST_ERROR, "status_code": None}
    raw, err = _post(
        "Reply exactly as requested.",
        "Reply with exactly: ASK MASTIC CLOUD LLM OK",
        timeout=timeout,
        max_tokens=24,
    )
    if err:
        LAST_ERROR = err
        return {"ok": False, "error": err, "status_code": None}
    LAST_ERROR = "" if raw else "Gemini returned no content."
    return {"ok": bool(raw), "status_code": 200, "text": raw, "error": LAST_ERROR or None}


def synthesize(question, evidence_text, language="ms", conversation_text="", mode="analytical", draft=""):
    global LAST_ERROR
    s = load_settings()
    if not s.get("gemini_api_key"):
        LAST_ERROR = "GEMINI_API_KEY is not configured."
        return None
    draft = str(draft or "")[:3200]
    evidence = str(evidence_text or "")[:7000]
    conversation = str(conversation_text or "")[:900]
    cap = max(240, min(int(s.get("max_output_tokens", 420)), 600))
    max_tokens = min(520 if mode == "analytical" else 300, cap)
    prompt = _primary_prompt(question, evidence, language, mode, draft, conversation)
    raw, err = _post(_system_prompt(language), prompt, timeout=60, max_tokens=max_tokens)
    if err:
        LAST_ERROR = err
        return None
    first = _clean(raw, language)
    if first and not _looks_bad(first, language) and _complete(first):
        LAST_ERROR = ""
        return first

    source = draft or evidence[:3200]
    if language == "ms":
        repair = (
            f"Soalan: {question}\n\nTeks disahkan:\n{source}\n\n"
            "Tulis semula sebagai jawapan akhir Bahasa Melayu Malaysia yang profesional dalam 3 hingga 4 ayat. "
            "Kekalkan semua fakta dan angka. Jangan terangkan proses. Jangan gunakan Bahasa Inggeris kecuali nama rasmi atau istilah teknikal. "
            "Pastikan ayat terakhir lengkap."
        )
    else:
        repair = (
            f"Question: {question}\n\nVerified text:\n{source}\n\n"
            "Rewrite this as a complete professional final answer in 3 to 4 sentences. Preserve every fact and number. "
            "Do not explain your process. End with a complete sentence."
        )
    raw2, err2 = _post(_system_prompt(language), repair, timeout=60, max_tokens=min(420, cap))
    if err2:
        if first:
            LAST_ERROR = ""
            return first
        LAST_ERROR = err2
        return None
    second = _clean(raw2, language)
    if second:
        LAST_ERROR = ""
        return second
    if first:
        LAST_ERROR = ""
        return first
    LAST_ERROR = "Gemini returned empty content."
    return None


def synthesize_stream(question, evidence_text, language="ms", conversation_text="", mode="analytical", draft=""):
    ans = synthesize(question, evidence_text, language, conversation_text, mode, draft)
    if ans:
        yield ans

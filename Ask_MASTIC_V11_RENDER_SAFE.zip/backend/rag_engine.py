from __future__ import annotations
import json, re, threading
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

ROOT = Path(__file__).resolve().parents[1]
CHUNKS_PATH = ROOT / 'index' / 'chunks.json'

STOP = set('yang dan atau untuk pada dalam daripada kepada dengan bagi ialah adalah ini itu the and or for of to in on a an is are was were from with report laporan'.split())

class RAGEngine:
    def __init__(self):
        self.lock = threading.Lock()
        self.chunks=[]; self.word=None; self.char=None; self.word_m=None; self.char_m=None
        self.load()

    def load(self):
        if not CHUNKS_PATH.exists():
            from ingest import build_index
            build_index()
        self.chunks=json.loads(CHUNKS_PATH.read_text(encoding='utf-8'))
        texts=[c['text'] for c in self.chunks]
        if not texts: return
        self.word=TfidfVectorizer(lowercase=True, ngram_range=(1,2), min_df=1, max_df=.98, sublinear_tf=True)
        self.char=TfidfVectorizer(lowercase=True, analyzer='char_wb', ngram_range=(3,5), min_df=1, max_features=80000, sublinear_tf=True)
        self.word_m=self.word.fit_transform(texts)
        self.char_m=self.char.fit_transform(texts)

    def rebuild(self):
        with self.lock:
            from ingest import build_index
            build_index(); self.load()

    @staticmethod
    def _years(q):
        return re.findall(r'\b(?:19|20)\d{2}\b', q)

    @staticmethod
    def _expand_query(query):
        q=query.lower()
        lex={
            'cabaran':'challenges challenge', 'bakat':'talent', 'kemahiran':'skills skill',
            'masa hadapan':'future', 'masa depan':'future', 'keutamaan':'priority prioritisation',
            'diprioritikan':'prioritised prioritized', 'kebolehlaksanaan':'feasibility',
            'daya tarikan':'attractiveness', 'tarikan':'attractiveness', 'strategi':'strategies strategy',
            'penyediaan':'preparation', 'pengekalan':'retention', 'pertumbuhan':'growth',
            'kepimpinan':'leadership', 'penempatan':'deployment', 'motivasi':'motivation',
            'daya saing':'competitiveness', 'ekosistem':'ecosystem', 'pendidikan':'education',
            'industri':'industry', 'pekerjaan':'jobs employment', 'teknologi':'technology',
            'kelestarian':'sustainability environmental', 'keselamatan digital':'digital security cyber defence',
            'kecerdasan buatan':'artificial intelligence ai', 'data':'data', 'tenaga':'energy',
            'pembuatan termaju':'advanced manufacturing', 'kesihatan':'healthcare biomedical',
            'pertanian':'agriculture food security', 'risiko':'risk', 'perancangan strategik':'strategic planning'
        }
        additions=[]
        for ms,en in lex.items():
            if ms in q:additions.append(en)
        return query+' '+' '.join(additions)

    def search(self, query, top_k=6, module=None):
        if not self.chunks: return []
        expanded=self._expand_query(query)
        qw=self.word.transform([expanded]); qc=self.char.transform([expanded])
        s=.72*linear_kernel(qw,self.word_m).ravel()+.28*linear_kernel(qc,self.char_m).ravel()
        ql=query.lower(); years=self._years(query)
        for i,c in enumerate(self.chunks):
            if module and module.lower() not in c.get('module','').lower(): s[i]*=.4
            if years:
                period=str(c.get('period',''))+' '+c.get('title','')
                if any(y in period for y in years): s[i]+=0.18
                elif c.get('module','').startswith('SPM'): s[i]*=.55
            if 'foresight' in ql and 'foresight' in (c.get('type','')+' '+c.get('module','')).lower(): s[i]+=0.18
        idx=np.argsort(s)[::-1][:max(top_k*3, top_k)]
        out=[]; seen=set()
        for i in idx:
            if s[i] < .035: continue
            c=dict(self.chunks[int(i)]); c['score']=float(s[i])
            key=(c['file'],c['page'])
            if key in seen: continue
            seen.add(key); out.append(c)
            if len(out)>=top_k: break
        return out

    def extractive_answer(self, query, hits, language='ms'):
        if not hits:
            return None
        terms=[t for t in re.findall(r'[a-zA-Z0-9]+',query.lower()) if len(t)>2 and t not in STOP]
        candidates=[]
        for rank,h in enumerate(hits):
            sentences=re.split(r'(?<=[.!?])\s+|\n+', h['text'])
            for pos,sent in enumerate(sentences):
                sent=' '.join(sent.split())
                if len(sent)<45 or len(sent)>520: continue
                low=sent.lower(); overlap=sum(1 for t in terms if t in low)
                score=h['score'] + overlap*.09 - rank*.015 - pos*.0005
                candidates.append((score,sent,h))
        candidates.sort(key=lambda x:x[0], reverse=True)
        chosen=[]; used=set()
        for _,sent,h in candidates:
            norm=re.sub(r'\W+',' ',sent.lower())[:120]
            if norm in used: continue
            used.add(norm); chosen.append((sent,h))
            if len(chosen)>=3: break
        if not chosen:
            chosen=[(' '.join(hits[0]['text'].split())[:900],hits[0])]
        body=' '.join(s for s,_ in chosen)
        if language=='en':
            prefix='Based on the indexed source documents: '
        else:
            prefix='Berdasarkan dokumen sumber yang telah diindeks: '
        return prefix+body

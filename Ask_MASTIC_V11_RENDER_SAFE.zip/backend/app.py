from __future__ import annotations
import json, re, shutil, uuid, time, sys
import requests as http_requests
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

ROOT=Path(__file__).resolve().parents[1]
PLATFORM=ROOT/'platform'; DOCS=ROOT/'documents'; DATA=ROOT/'data'; INDEX=ROOT/'index'
for d in [DOCS,DATA,INDEX]: d.mkdir(exist_ok=True)
sys.path.insert(0,str(Path(__file__).resolve().parent))

from rag_engine import RAGEngine
from structured_engine import answer_structured
from evidence_builder import build_evidence_pack, is_analytical
from llm_provider import synthesize, provider_status, live_test
from config_manager import config_status
from ingest import infer_meta, load_meta, save_meta

app=FastAPI(title='Ask MASTIC Web Knowledge API',version='web-gemini-1.0')
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=False,allow_methods=['*'],allow_headers=['*'])
app.mount('/documents',StaticFiles(directory=str(DOCS)),name='documents')
rag:RAGEngine|None=None
HISTORY:dict[str,list[dict]]={}

class AskRequest(BaseModel):
    question:str
    language:str='ms'
    module:Optional[str]=None
    context:dict={}
    session_id:Optional[str]=None

@app.on_event('startup')
def startup():
    global rag
    rag=RAGEngine()



# ===== V11 SAFE COPY: hosted proxy routes =====
STABLE_ASK_MASTIC = 'https://mastic-talent-intelligence.onrender.com'
FORESIGHT_UPSTREAM = 'https://mastic.mosti.gov.my'


def _rewrite_foresight_text(data: bytes, content_type: str) -> bytes:
    charset='utf-8'
    m=re.search(r'charset=([\\w\\-]+)', content_type or '', re.I)
    if m: charset=m.group(1)
    text=data.decode(charset, errors='replace')
    proxy='/foresight-proxy/'
    text=text.replace('https://mastic.mosti.gov.my/', proxy)
    text=text.replace('http://mastic.mosti.gov.my/', proxy)
    text=text.replace('//mastic.mosti.gov.my/', proxy)
    if 'text/html' in (content_type or '').lower():
        text=re.sub(r'<meta[^>]+http-equiv=["\\\']Content-Security-Policy["\\\'][^>]*>', '', text, flags=re.I)
        for attr in ('src','href','action','poster'):
            text=text.replace(f'{attr}="/', f'{attr}="{proxy}')
            text=text.replace(f"{attr}='/", f"{attr}='{proxy}")
        text=text.replace('url(/', f'url({proxy}')
        text=text.replace('fetch("/', f'fetch("{proxy}')
        text=text.replace("fetch('/", f"fetch('{proxy}")
        text=text.replace('import("/', f'import("{proxy}')
        text=text.replace("import('/", f"import('{proxy}")
    elif 'text/css' in (content_type or '').lower():
        text=text.replace('url(/', f'url({proxy}')
    return text.encode('utf-8')


def _is_textual(content_type:str)->bool:
    ct=(content_type or '').lower()
    return ct.startswith('text/') or 'javascript' in ct or 'json' in ct or 'xml' in ct or 'svg' in ct


@app.api_route('/foresight-proxy/{path:path}', methods=['GET','POST','HEAD'])
async def foresight_proxy(path:str, request:Request):
    upstream=FORESIGHT_UPSTREAM + '/' + path.lstrip('/')
    if request.url.query:
        upstream += '?' + request.url.query
    body=await request.body() if request.method=='POST' else None
    headers={
        'User-Agent':'Mozilla/5.0 Ask-MASTIC-Foresight-Proxy/2.0',
        'Accept':request.headers.get('accept','*/*'),
        'Accept-Language':request.headers.get('accept-language','en-US,en;q=0.9')
    }
    if request.headers.get('content-type'):
        headers['Content-Type']=request.headers['content-type']
    try:
        r=http_requests.request(request.method, upstream, data=body, headers=headers, timeout=30, allow_redirects=True)
    except Exception as exc:
        msg=(f'<html><body style="font-family:Segoe UI,Arial;padding:28px">'
             f'<h3>Foresight belum dapat dimuatkan.</h3><p>{type(exc).__name__}: {exc}</p>'
             f'<p><a href="https://mastic.mosti.gov.my/services/dashboard/foresight/stem-linkage.html#read" target="_blank">Buka sumber rasmi Foresight</a></p>'
             f'</body></html>')
        return Response(content=msg,status_code=502,media_type='text/html')
    ctype=r.headers.get('content-type','application/octet-stream')
    media=ctype.split(';',1)[0].strip()
    data=r.content
    if _is_textual(ctype):
        data=_rewrite_foresight_text(data,ctype)
    return Response(content=(b'' if request.method=='HEAD' else data),status_code=r.status_code,media_type=media,
                    headers={'Cache-Control':'public, max-age=300','Access-Control-Allow-Origin':'*'})


@app.get('/api/health')
def stable_health_proxy():
    try:
        r=http_requests.get(STABLE_ASK_MASTIC+'/api/health',timeout=45)
        return JSONResponse(r.json(),status_code=r.status_code)
    except Exception as exc:
        return JSONResponse({'ok':False,'service_up':True,'upstream':'waking','error':str(exc)},status_code=200)


@app.post('/api/ask')
def stable_ask_proxy(req:AskRequest):
    try:
        r=http_requests.post(STABLE_ASK_MASTIC+'/api/ask',json=req.model_dump(),timeout=110)
        try:
            payload=r.json()
        except Exception:
            payload={'detail':r.text[:1000]}
        return JSONResponse(payload,status_code=r.status_code)
    except Exception as exc:
        raise HTTPException(503,f'Ask MASTIC stable backend belum memberi respons: {exc}')


@app.get('/')
def home(): return FileResponse(PLATFORM/'index.html')

@app.get('/api/local-health')
def health():
    s=provider_status(); c=config_status()
    return {
        'ok':s.get('provider')=='gemini' and bool(s.get('configured')),
        'service_up':True,
        'all_answers_require_llm':True,
        'service':'Ask MASTIC Web Knowledge',
        'version':'web-gemini-1.0',
        'chunks':len(rag.chunks) if rag else 0,
        'llm_provider':s.get('provider'),
        'llm_model':s.get('model'),
        'llm_configured':s.get('configured'),
        'llm_last_error':s.get('last_error'),
        'config_settings_exists':c.get('settings_exists'),
    }

@app.get('/api/config-debug')
def config_debug(): return config_status()

@app.get('/api/llm-test')
def llm_test():
    s=provider_status()
    if not s.get('configured'):
        return {'ok':False,'configured':False,'provider':s.get('provider'),'model':s.get('model'),'error':'Local LLM is not configured.'}
    return {'configured':True,'provider':s.get('provider'),'model':s.get('model'),**live_test()}


def documents_records():
    meta=load_meta(); rows=[]
    indexed_files={c['file'] for c in (rag.chunks if rag else [])}
    for p in sorted(DOCS.glob('*.pdf')):
        m=dict(infer_meta(p)); m.update(meta.get(p.name,{}))
        rows.append({'id':p.name,'fileName':p.name,'title':m.get('title',p.stem),'module':m.get('module','Other'),
                     'type':m.get('type','Source Document'),'period':m.get('period',''),'owner':m.get('owner',''),
                     'access':m.get('access','Repository'),'ai':True,'indexed':p.name in indexed_files,
                     'size':p.stat().st_size,'mime':'application/pdf','path':f'/documents/{p.name}'})
    return rows

@app.get('/api/documents')
def list_documents(): return {'documents':documents_records()}

@app.post('/api/documents/upload')
async def upload_document(file:UploadFile=File(...),module:str=Form('Other'),type:str=Form('Source Document'),
                          title:str=Form(''),period:str=Form(''),access:str=Form('Internal'),ai:str=Form('true')):
    if not file.filename or not file.filename.lower().endswith('.pdf'):
        raise HTTPException(400,'PDF only for the RAG repository in this demo.')
    safe=re.sub(r'[^A-Za-z0-9._-]+','_',Path(file.filename).name)
    dest=DOCS/safe
    if dest.exists(): dest=DOCS/f'{dest.stem}_{uuid.uuid4().hex[:6]}{dest.suffix}'
    with dest.open('wb') as f: shutil.copyfileobj(file.file,f)
    meta=load_meta(); inferred=infer_meta(dest)
    meta[dest.name]={**inferred,'module':module or inferred['module'],'type':type or inferred['type'],
                     'title':title or inferred['title'],'period':period or inferred['period'],'access':access}
    save_meta(meta)
    if ai.lower() in {'true','1','yes','on'}: rag.rebuild()
    return {'ok':True,'document':next((d for d in documents_records() if d['fileName']==dest.name),None)}

@app.post('/api/reindex')
def reindex():
    rag.rebuild(); return {'ok':True,'chunks':len(rag.chunks),'documents':documents_records()}


def infer_rag_module(q:str,module:Optional[str]):
    l=q.lower()
    if 'foresight' in l or any(k in l for k in ['future stem','skill area','kemahiran masa hadapan','delphi']): return 'Foresight'
    if 'spm' in l or any(k in l for k in ['matematik','fizik','kimia','biologi','gpmp','gpk','gpn']): return 'SPM'
    if module:
        if 'foresight' in module.lower(): return 'Foresight'
        if 'spm' in module.lower(): return 'SPM'
    return None


def _history_for(session_id:Optional[str]):
    if not session_id: return []
    return HISTORY.setdefault(session_id,[])


def _needs_history_resolution(q:str):
    l=q.lower().strip()
    generic=['kenapa jadi','kenapa macam','why is that','why so','apa implikasi','what implication','bagaimana pula',
             'what about','jelaskan lagi','explain further','yang ini','yang tadi','apa maksudnya','so what']
    return len(l)<55 and any(k in l for k in generic)


def _conversation_text(hist:list[dict],limit:int=2):
    rows=[]
    for item in hist[-limit*2:]:
        role='Pengguna' if item.get('role')=='user' else 'Ask MASTIC'
        text=' '.join(str(item.get('text','')).split())[:420]
        rows.append(f'{role}: {text}')
    return '\n'.join(rows)


def _append_history(hist:list[dict],question:str,answer:str):
    hist.append({'role':'user','text':question}); hist.append({'role':'assistant','text':answer})
    if len(hist)>8: del hist[:-8]


def _merge_sources(*groups):
    out=[]; seen=set()
    for g in groups:
        for s in g or []:
            k=(s.get('title'),s.get('page'),s.get('view'),s.get('url'))
            if k in seen: continue
            seen.add(k); out.append(s)
    return out


def _require_llm():
    status=provider_status()
    if status.get('provider')!='gemini' or not status.get('configured'):
        raise HTTPException(503,'Ask MASTIC belum dikonfigurasi dengan GEMINI_API_KEY pada server.')
    return status


def _resolve_language(question:str, requested:str)->str:
    q=' '+question.lower()+' '
    ms_markers=[' apakah ',' bagaimana ',' mengapa ',' kenapa ',' berapa ',' hingga ',' daripada ',' prestasi ',' matematik ',
                ' bakat ',' pekerjaan ',' kadar ',' tahun ',' jurang ',' ketidaksepadanan ',' sumber ',' yang ',' untuk ',' dengan ']
    en_markers=[' what ',' how ',' why ',' from ',' performance ',' mathematics ',' talent ',' occupation ',' rate ',' year ',' mismatch ']
    ms=sum(1 for x in ms_markers if x in q); en=sum(1 for x in en_markers if x in q)
    if ms>=2 or (ms>en and ms>0): return 'ms'
    if en>=2 or (en>ms and en>0): return 'en'
    return 'en' if requested=='en' else 'ms'


def _extract_spm_trend_draft(pack:dict)->str:
    text=pack.get('text','')
    marker='RUMUSAN ANALITIK TERBITAN:'
    if marker not in text: return ''
    tail=text.split(marker,1)[1].strip().splitlines()
    useful=[x.strip() for x in tail if x.strip()][:2]
    return ' '.join(useful)


def _draft_for(question:str, pack:dict, structured:dict|None, analytical:bool, no_evidence:bool, language:str)->str:
    if no_evidence:
        return ('Sumber yang tersedia dalam repositori belum mencukupi untuk mengesahkan jawapan kepada soalan ini.'
                if language=='ms' else 'The available repository does not contain enough verified evidence to answer this question.')
    # For BM management answers, prefer a deterministic insight draft calculated from the verified data.
    # Ollama remains mandatory, but its job is to edit/synthesise rather than invent the analysis.
    if language=='ms' and pack.get('draft_ms'):
        return pack['draft_ms']
    if language=='ms' and (pack.get('topics') or [])==['spm_subject']:
        d=_extract_spm_trend_draft(pack)
        if d: return d
    if structured and structured.get('answer') and not analytical:
        return structured['answer']
    return ''


def _llm_or_fail(question:str,evidence:str,language:str,hist:list[dict],mode:str,draft:str=''):
    conversation=_conversation_text(hist) if _needs_history_resolution(question) else ''
    answer=synthesize(question,evidence,language,conversation,mode=mode,draft=draft)
    if answer: return answer
    err=provider_status().get('last_error') or 'Cloud LLM did not return a valid final answer.'
    raise HTTPException(503,f'Jawapan tidak dipaparkan kerana semakan kualiti gagal: {err}')


@app.post('/api/local-ask')
def ask(req:AskRequest):
    started=time.perf_counter()
    q=req.question.strip()
    if not q: raise HTTPException(400,'Question is empty.')
    language=_resolve_language(q,req.language)
    ql=q.lower(); hist=_history_for(req.session_id); status=_require_llm()

    # Help/system questions still pass through Ollama, but from a concise factual draft.
    if any(k in ql for k in ['apa sumber yang tersedia','what sources are available','sumber tersedia','available sources']):
        docs=documents_records(); names=', '.join(d['title'] for d in docs)
        draft=('Sumber yang tersedia merangkumi data analitik SPM, E&E Supply & Demand, Graduate Mismatch serta dokumen PDF yang telah diindeks. '
               'Dokumen berindeks termasuk: '+names+'.')
        answer=_llm_or_fail(q,draft,language,hist,'direct',draft)
        sources=[{'title':'Data Analitik SPM','module':'SPM Intelligence','kind':'data','view':'spm'},
                 {'title':'E&E Supply & Demand','module':'E&E Supply & Demand','kind':'data','view':'ee'},
                 {'title':'Graduate Mismatch','module':'Graduate Mismatch','kind':'data','view':'ee'}]
        _append_history(hist,q,answer)
        return JSONResponse({'answer':answer,'sources':sources,'route':'ollama:system','confidence':'high','llm_used':True,
                             'llm_model':status.get('model'),'processing_ms':round((time.perf_counter()-started)*1000,1)})

    retrieval_q=q
    if _needs_history_resolution(q) and hist:
        prev=[x['text'] for x in hist if x.get('role')=='user']
        if prev: retrieval_q=prev[-1]+' | Susulan: '+q

    t=time.perf_counter()
    structured=answer_structured(retrieval_q,language,req.context)
    pack=build_evidence_pack(retrieval_q,req.context)
    structured_ms=(time.perf_counter()-t)*1000

    rag_module=infer_rag_module(retrieval_q,req.module)
    explicit_doc=any(k in ql for k in ['laporan','report','dokumen','document','metodologi','methodology','delphi','muka surat','page','pdf'])
    wants_document=explicit_doc or rag_module=='Foresight' or (not pack.get('text') and rag_module is not None)
    t=time.perf_counter()
    hits=rag.search(retrieval_q,top_k=2,module=rag_module) if (rag and wants_document) else []
    rag_ms=(time.perf_counter()-t)*1000

    doc_evidence='\n\n'.join(f"[DOKUMEN: {h['title']} | halaman {h['page']}] {h['text']}" for h in hits[:2])
    evidence_parts=[]
    if pack.get('text'): evidence_parts.append(pack['text'])
    elif structured and structured.get('answer'): evidence_parts.append(structured['answer'])
    if doc_evidence: evidence_parts.append(doc_evidence)
    no_evidence=not evidence_parts
    evidence='\n\n---\n\n'.join(evidence_parts) if evidence_parts else 'Tiada bukti yang dapat disahkan dalam sumber tersedia.'

    analytical=is_analytical(q) or pack.get('mode_hint')=='analytical' or len(pack.get('topics',[]))>1 or _needs_history_resolution(q)
    mode='analytical' if analytical else 'direct'
    draft=_draft_for(q,pack,structured,analytical,no_evidence,language)

    t=time.perf_counter()
    answer=_llm_or_fail(q,evidence,language,hist,mode,draft)
    llm_ms=(time.perf_counter()-t)*1000

    doc_sources=[{'title':h['title'],'module':h['module'],'kind':'document','page':h['page'],'url':h['url'],'score':round(h['score'],3)} for h in hits[:2]]
    sources=_merge_sources(pack.get('sources'),([] if pack.get('text') else (structured.get('sources',[]) if structured else [])),doc_sources)
    if no_evidence: route='llm:no-evidence'; confidence='low'
    elif pack.get('text') and hits: route='llm:hybrid'; confidence='high'
    elif pack.get('text') or structured: route='llm:structured'; confidence='high'
    else: route='llm:rag'; confidence='medium'

    total=(time.perf_counter()-started)*1000
    print(f'[Ask MASTIC FINAL] route={route} structured={structured_ms:.1f}ms rag={rag_ms:.1f}ms llm={llm_ms:.1f}ms total={total:.1f}ms model={status.get("model")}')
    _append_history(hist,q,answer)
    return JSONResponse({'answer':answer,'sources':sources,'route':route,'confidence':confidence,
                         'llm_used':True,'llm_model':status.get('model'),'analysis_mode':mode,
                         'processing_ms':round(total,1),'timing':{'structured_ms':round(structured_ms,1),'rag_ms':round(rag_ms,1),'llm_ms':round(llm_ms,1)}})

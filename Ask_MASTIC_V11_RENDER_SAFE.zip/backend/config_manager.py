from __future__ import annotations
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DEFAULT_MODEL = "gemini-3.8-flash"


def load_settings():
    return {
        "provider": "gemini",
        "gemini_model": os.getenv("GEMINI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL,
        "gemini_api_key": os.getenv("GEMINI_API_KEY", "").strip(),
        "max_output_tokens": int(os.getenv("MAX_OUTPUT_TOKENS", "420")),
    }


def config_status():
    s = load_settings()
    key = s["gemini_api_key"]
    return {
        "project_root": str(ROOT),
        "settings_path": "environment variables",
        "settings_exists": True,
        "provider": "gemini",
        "model": s["gemini_model"],
        "configured": bool(key),
        "gemini_api_key_present": bool(key),
        "key_chars": len(key),
    }

Ask MASTIC Web Demo (Lite)

Purpose: public demo deployment without the original PDF files. Structured datasets and the prebuilt RAG index are included, so SPM, E&E, mismatch and foresight questions can still use indexed evidence. The source PDFs are omitted only to make mobile upload/deployment faster.

Required Render environment variable:
GEMINI_API_KEY=<your Google AI Studio API key>

Optional:
GEMINI_MODEL=gemini-3.8-flash
MAX_OUTPUT_TOKENS=420

Render build command:
pip install -r backend/requirements.txt

Render start command:
python -m uvicorn app:app --app-dir backend --host 0.0.0.0 --port $PORT

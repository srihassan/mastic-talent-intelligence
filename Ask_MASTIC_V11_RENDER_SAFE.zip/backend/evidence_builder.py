from __future__ import annotations
import re
from typing import Any

from structured_engine import SPM, SPM_CORE, SUP, MIS, norm, years, spm_subject, val_for, source, foresight_source, find_job

ANALYTIC_TERMS = [
    'insight','analisis','analysis','prestasi','performance','trend','aliran','corak','pattern',
    'implikasi','implication','apa maksud','what does','kenapa','why','jelaskan','explain',
    'banding','compare','perbandingan','rumus','summary','ringkasan','overview','kedudukan',
    'dapatan','finding','utama','key','so what','unjuran','outlook','projection','apa yang boleh dilihat','apa yang dapat dilihat',
    'apa yang boleh dirumuskan','interpretasi','interpret'
]

DIRECT_TERMS = [
    'berapa','berapa banyak','what is','how many','nilai','kadar','gpmp','gpk','gpn',
    'bilangan calon','candidate','calon','defisit','lebihan','surplus'
]

JOB_MS = {
    '1223':'Pengurus Penyelidikan dan Pembangunan (R&D)',
    '1321':'Pengurus Pembuatan',
    '2141':'Jurutera Industri dan Pengeluaran',
    '2151':'Jurutera Elektrik',
    '2152':'Jurutera Elektronik',
    '3113':'Juruteknik Kejuruteraan Elektrik',
    '3114':'Juruteknik Kejuruteraan Elektronik',
    '3122':'Penyelia Pembuatan',
    '7412':'Mekanik dan Pemasang Elektrik',
    '7421':'Mekanik Elektronik dan Perkhidmatan',
}


def fmt_num(v: Any, dec: int = 1) -> str:
    if v is None:
        return '—'
    if isinstance(v, int):
        return f'{v:,}'
    f=float(v)
    if abs(f-round(f))<1e-9:
        return f'{int(round(f)):,}'
    return f'{f:,.{dec}f}'


def is_analytical(question: str) -> bool:
    q=norm(question)
    return any(t in q for t in ANALYTIC_TERMS)


def _spm_subject_pack(question: str):
    hit=spm_subject(question)
    if not hit:
        return None
    _,obj=hit
    series=obj.get('series',{})
    if not series:
        return None
    requested=[y for y in years(question) if str(y) in series]
    broad=is_analytical(question) or not requested
    selected=sorted(map(int,series.keys())) if broad else requested
    if not selected:
        selected=[max(map(int,series.keys()))]
    lines=[f"MATA PELAJARAN SPM: {obj['name']}",
           'Kaedah tafsiran: bagi GPMP, nilai LEBIH RENDAH menunjukkan prestasi lebih baik.',
           'Tahun | GPMP | Kadar lulus | Sekurang-kurangnya kepujian | Kadar gagal | Calon menduduki']
    for y in selected:
        d=series[str(y)]
        lines.append(f"{y} | {fmt_num(d.get('gpmp'),2)} | {fmt_num(d.get('passrate'))}% | {fmt_num(d.get('credit_plus_pct'))}% | {fmt_num(d.get('fail'))}% | {fmt_num(d.get('candidates'),0)}")
    ys=sorted(map(int,series.keys()))
    first,last=ys[0],ys[-1]
    d0,dl=series[str(first)],series[str(last)]
    worst=max(ys,key=lambda y: series[str(y)].get('gpmp',-999))
    best=min(ys,key=lambda y: series[str(y)].get('gpmp',999))
    lines += [
        'DAPATAN TERBITAN (dikira daripada dataset berstruktur):',
        f"GPMP {first}→{last}: {d0['gpmp']:.2f}→{dl['gpmp']:.2f} ({dl['gpmp']-d0['gpmp']:+.2f}; lower is better).",
        f"GPMP tertinggi/paling lemah dalam siri: {worst} = {series[str(worst)]['gpmp']:.2f}; GPMP terendah/paling baik: {best} = {series[str(best)]['gpmp']:.2f}.",
        f"Pass rate {first}→{last}: {d0['passrate']:.1f}%→{dl['passrate']:.1f}% ({dl['passrate']-d0['passrate']:+.1f} percentage points).",
        f"Credit-or-better {first}→{last}: {d0['credit_plus_pct']:.1f}%→{dl['credit_plus_pct']:.1f}% ({dl['credit_plus_pct']-d0['credit_plus_pct']:+.1f} percentage points).",
        f"Fail rate {first}→{last}: {d0['fail']:.1f}%→{dl['fail']:.1f}% ({dl['fail']-d0['fail']:+.1f} percentage points).",
    ]
    if 2021 in ys and last>2021:
        d21=series['2021']
        lines += [
            f"Recovery comparison 2021→{last}: GPMP {d21['gpmp']:.2f}→{dl['gpmp']:.2f}; pass rate {d21['passrate']:.1f}%→{dl['passrate']:.1f}%; credit-or-better {d21['credit_plus_pct']:.1f}%→{dl['credit_plus_pct']:.1f}%.",
        ]
    gp_delta=dl['gpmp']-d0['gpmp']
    if abs(gp_delta) < 0.005:
        gp_summary=f"GPMP {last} kembali ke paras {first} ({dl['gpmp']:.2f}); tiada perubahan bersih pada GPMP antara awal dan akhir tempoh."
    elif gp_delta < 0:
        gp_summary=f"GPMP bertambah baik daripada {d0['gpmp']:.2f} kepada {dl['gpmp']:.2f} (lebih rendah = lebih baik)."
    else:
        gp_summary=f"GPMP merosot daripada {d0['gpmp']:.2f} kepada {dl['gpmp']:.2f} (lebih tinggi = lebih lemah)."
    support_weaker=(dl['passrate'] < d0['passrate'] and dl['credit_plus_pct'] < d0['credit_plus_pct'] and dl['fail'] > d0['fail'])
    lines += [
        'RUMUSAN ANALITIK TERBITAN:',
        gp_summary,
        (f"Walaupun GPMP akhir kembali ke paras awal, indikator hasil lain melemah: kadar lulus {d0['passrate']:.1f}%→{dl['passrate']:.1f}%, sekurang-kurangnya kepujian {d0['credit_plus_pct']:.1f}%→{dl['credit_plus_pct']:.1f}%, dan kadar gagal {d0['fail']:.1f}%→{dl['fail']:.1f}%. Rumusan yang tepat ialah trend bercampur, bukan peningkatan keseluruhan." if support_weaker and abs(gp_delta)<0.005 else 'Tafsir indikator secara bersama; jangan simpulkan peningkatan atau kemerosotan keseluruhan jika indikator bergerak dalam arah yang berbeza.'),
    ]
    if abs(gp_delta) < 0.005 and support_weaker:
        draft_ms=(
            f"Prestasi {obj['name']} SPM menunjukkan trend bercampur antara {first} hingga {last}. "
            f"GPMP {last} ialah {dl['gpmp']:.2f}, sama seperti {first}, tetapi kadar lulus menurun daripada {d0['passrate']:.1f}% kepada {dl['passrate']:.1f}%, "
            f"kadar sekurang-kurangnya kepujian daripada {d0['credit_plus_pct']:.1f}% kepada {dl['credit_plus_pct']:.1f}%, dan kadar gagal meningkat daripada {d0['fail']:.1f}% kepada {dl['fail']:.1f}%. "
            f"GPMP terbaik direkodkan pada {best} ({series[str(best)]['gpmp']:.2f}) dan paling lemah pada {worst} ({series[str(worst)]['gpmp']:.2f}). "
            f"Ini menunjukkan pemulihan GPMP belum disertai pengukuhan pada indikator hasil lain; prestasi keseluruhan tidak wajar dianggap bertambah baik hanya berdasarkan GPMP."
        )
    else:
        draft_ms=(
            f"Bagi {obj['name']} SPM, {gp_summary} Kadar lulus berubah daripada {d0['passrate']:.1f}% kepada {dl['passrate']:.1f}%, "
            f"kadar sekurang-kurangnya kepujian daripada {d0['credit_plus_pct']:.1f}% kepada {dl['credit_plus_pct']:.1f}%, dan kadar gagal daripada {d0['fail']:.1f}% kepada {dl['fail']:.1f}%. "
            f"GPMP terbaik dalam siri ialah {series[str(best)]['gpmp']:.2f} pada {best}, manakala paling lemah ialah {series[str(worst)]['gpmp']:.2f} pada {worst}. "
            f"Tafsiran perlu dibuat berdasarkan beberapa indikator secara bersama, bukan GPMP sahaja."
        )
    return {'text':'\n'.join(lines),'sources':[source('Dataset Analitik Mata Pelajaran SPM','SPM Intelligence','spm')],
            'topic':'spm_subject','draft_ms':draft_ms,'mode_hint':'analytical'}


def _spm_national_pack(question: str):
    q=norm(question)
    if not ('spm' in q or any(k in q for k in ['gpk','gpn','pensijilan','sijil','bandar','luar bandar'])):
        return None
    lines=['SPM NATIONAL SERIES 2018–2025',
           'Year | GPN/GPK | Certificate eligible | Registered candidates | Urban-rural gap']
    for y in sorted(SPM_CORE):
        d=SPM_CORE[y]
        lines.append(f"{y} | {d['average']:.2f} ({d['averageLabel']}) | {d['cert']:.2f}% | {d['registered']:,} | {d['gap']:.2f}")
    a,b=SPM_CORE[2018],SPM_CORE[2025]
    lines += [
        'DERIVED FACTS:',
        f"National average 2018→2025: {a['average']:.2f}→{b['average']:.2f}; lower is better.",
        f"Certificate eligibility 2018→2025: {a['cert']:.2f}%→{b['cert']:.2f}% ({b['cert']-a['cert']:+.2f} percentage points).",
        f"Registered candidates 2018→2025: {a['registered']:,}→{b['registered']:,} ({b['registered']-a['registered']:+,}).",
        f"Urban-rural gap 2018→2025: {a['gap']:.2f}→{b['gap']:.2f}.",
    ]
    avg_delta=b['average']-a['average']
    avg_phrase=('bertambah baik' if avg_delta < 0 else ('merosot' if avg_delta > 0 else 'tidak berubah'))
    draft_ms=(
        f"Secara nasional, purata SPM {avg_phrase} daripada {a['average']:.2f} pada 2018 kepada {b['average']:.2f} pada 2025 (lebih rendah = lebih baik). "
        f"Kadar layak dianugerahkan sijil berubah daripada {a['cert']:.2f}% kepada {b['cert']:.2f}%, manakala bilangan calon berdaftar berubah daripada {a['registered']:,} kepada {b['registered']:,}. "
        f"Jurang bandar-luar bandar pula berubah daripada {a['gap']:.2f} kepada {b['gap']:.2f}. "
        f"Dapatan ini perlu dibaca sebagai beberapa dimensi prestasi yang berbeza; perubahan purata nasional tidak semestinya bermaksud jurang akses atau outcome telah bergerak pada kadar yang sama."
    )
    return {'text':'\n'.join(lines),'sources':[source('Siri Analitik Nasional SPM','SPM Intelligence','spm')],
            'topic':'spm_national','draft_ms':draft_ms,'mode_hint':'analytical'}


def _mismatch_pack(question: str, context=None):
    q=norm(question)
    if not (any(k in q for k in ['mismatch','ketidaksepadanan','tak sepadan','tidak sepadan','menegak','mendatar','vertical','horizontal','tvet']) or (context or {}).get('ee_tab')=='mismatch'):
        return None
    o=MIS['overall']; m=MIS['manufacturing']
    lines=['GRADUATE MISMATCH STRUCTURED DATA',
           'Definitions: AP=any mismatch; VP=vertical mismatch; HP=horizontal mismatch; DP=both vertical and horizontal.',
           f"Overall, all graduates: AP {o['all']['ap']:.1f}%; VP {o['all']['vp']:.1f}%; HP {o['all']['hp']:.1f}%; DP {o['all']['dp']:.1f}%.",
           f"Overall, TVET: AP {o['tvet']['ap']:.1f}%; VP {o['tvet']['vp']:.1f}%; HP {o['tvet']['hp']:.1f}%; DP {o['tvet']['dp']:.1f}%.",
           f"Overall, IPT/non-TVET: AP {o['ipt']['ap']:.1f}%; VP {o['ipt']['vp']:.1f}%; HP {o['ipt']['hp']:.1f}%; DP {o['ipt']['dp']:.1f}%.",
           f"Manufacturing, all graduates: AP {m['all']['ap']:.1f}%; VP {m['all']['vp']:.1f}%; HP {m['all']['hp']:.1f}%; DP {m['all']['dp']:.1f}%.",
           f"Manufacturing, TVET: AP {m['tvet']['ap']:.1f}%; VP {m['tvet']['vp']:.1f}%; HP {m['tvet']['hp']:.1f}%; DP {m['tvet']['dp']:.1f}%.",
           f"Manufacturing, IPT/non-TVET: AP {m['ipt']['ap']:.1f}%; VP {m['ipt']['vp']:.1f}%; HP {m['ipt']['hp']:.1f}%; DP {m['ipt']['dp']:.1f}%.",
           'Annual AP trend, all graduates: '+', '.join(f"{x['label']} {x['ap']:.1f}%" for x in o['all'].get('by_tahun',[]))+'.',
           'DERIVED FACTS:',
           f"TVET AP minus IPT/non-TVET AP: {o['tvet']['ap']-o['ipt']['ap']:+.1f} percentage points.",
           f"Manufacturing AP versus overall AP: {m['all']['ap']:.1f}% versus {o['all']['ap']:.1f}% ({m['all']['ap']-o['all']['ap']:+.1f} percentage points).",
    ]
    annual=o['all'].get('by_tahun',[])
    if annual:
        peak=max(annual,key=lambda x:x['ap']); low=min(annual,key=lambda x:x['ap'])
        lines.append(f"Annual AP peak: {peak['label']} = {peak['ap']:.1f}%; lowest: {low['label']} = {low['ap']:.1f}%.")
        lines.append(f"2018→2024 AP: {annual[0]['ap']:.1f}%→{annual[-1]['ap']:.1f}% ({annual[-1]['ap']-annual[0]['ap']:+.1f} percentage points).")
    draft_ms=(
        f"Ketidaksepadanan graduan bukan sekadar isu bilangan graduan, tetapi kesepadanan antara kelayakan, bidang dan pekerjaan. "
        f"Bagi semua graduan, kadar ketidaksepadanan keseluruhan ialah {o['all']['ap']:.1f}%; dalam sektor pembuatan, kadarnya {m['all']['ap']:.1f}%. "
        f"TVET merekodkan ketidaksepadanan menegak {o['tvet']['vp']:.1f}% dan mendatar {o['tvet']['hp']:.1f}%, berbanding bukan TVET masing-masing {o['ipt']['vp']:.1f}% dan {o['ipt']['hp']:.1f}%. "
        f"Isyarat utamanya ialah pertambahan bekalan graduan sahaja tidak mencukupi jika bidang pengajian dan aras pekerjaan tidak sepadan dengan keperluan pasaran kerja."
    )
    return {'text':'\n'.join(lines),'sources':[source('Dataset Analitik Ketidaksepadanan Graduan','Graduate Mismatch','ee')],
            'topic':'mismatch','draft_ms':draft_ms,'mode_hint':'analytical'}


def _supply_pack(question: str, context=None):
    q=norm(question)
    if not (any(k in q for k in ['supply','demand','bekalan','permintaan','defisit','surplus','lebihan','kekurangan','pekerjaan','2040']) or (context or {}).get('ee_tab')=='supply'):
        return None
    requested=years(question)
    y=requested[-1] if requested and requested[-1] in SUP['years'] else 2040
    def aggregate(year):
        rows=[]; ts=td=0.0
        for code,j in SUP['jobs'].items():
            s=val_for(j,'supply',year); d=val_for(j,'demand',year)
            if s is None or d is None: continue
            ts+=s; td+=d; rows.append((s-d,code,j['name'],s,d))
        return ts,td,rows
    latest=2025 if 2025 in SUP['years'] else 2024
    ts0,td0,_=aggregate(latest)
    ts,td,rows=aggregate(y)
    deficits=sorted([r for r in rows if r[0]<0])
    surpluses=sorted([r for r in rows if r[0]>=0],reverse=True)
    lines=['E&E SUPPLY-DEMAND STRUCTURED DATA',
           f"Latest actual aggregate ({latest}, 10 focus occupations): supply {ts0:,.1f}; demand {td0:,.1f}; gap {ts0-td0:+,.1f}.",
           f"Aggregate {y} (10 focus occupations): supply {ts:,.1f}; demand {td:,.1f}; gap {ts-td:+,.1f}.",
           f"Deficit occupations in {y}: "+'; '.join(f"{JOB_MS.get(code,name)} [MASCO {code}] deficit {abs(g):,.1f} (supply {s:,.1f}; demand {d:,.1f})" for g,code,name,s,d in deficits)+'.',
           f"Surplus occupations in {y}: "+'; '.join(f"{JOB_MS.get(code,name)} [MASCO {code}] surplus {g:,.1f}" for g,code,name,s,d in surpluses)+'.',
           'DERIVED FACTS:',
           f"Aggregate gap change {latest}→{y}: {(ts-td)-(ts0-td0):+,.1f}.",
           f"Number of deficit occupations in {y}: {len(deficits)} of {len(rows)}; surplus occupations: {len(surpluses)} of {len(rows)}.",
           'Interpretation constraint: an aggregate surplus does NOT by itself imply that every occupation has sufficient talent; occupation-level gaps must be examined separately.'
    ]
    job_hit=find_job(question)
    if re.search(r'defisit|kekurangan', q) and not job_hit:
        deficit_items=', '.join(
            f"{JOB_MS.get(code,name)} ({abs(g):,.0f})" for g,code,name,s,d in deficits
        )
        largest=deficits[0] if deficits else None
        largest_text=(f"Defisit terbesar ialah {JOB_MS.get(largest[1],largest[2])}, sekitar {abs(largest[0]):,.0f}. " if largest else '')
        draft_ms=(
            f"Pada {y}, {len(deficits)} daripada {len(rows)} pekerjaan fokus E&E diunjurkan mengalami defisit: {deficit_items}. "
            f"{largest_text}"
            f"Pada masa yang sama, agregat 10 pekerjaan masih menunjukkan lebihan kira-kira {ts-td:,.0f} (bekalan {ts:,.0f} berbanding permintaan {td:,.0f}). "
            f"Ini menunjukkan lebihan agregat tidak bermaksud semua pekerjaan mempunyai bekalan mencukupi; jurang utama ialah ketidakselarasan bekalan mengikut pekerjaan."
        )
        mode_hint='analytical'
    elif re.search(r'surplus|lebihan', q) and not job_hit:
        surplus_items=', '.join(f"{JOB_MS.get(code,name)} ({g:,.0f})" for g,code,name,s,d in surpluses)
        draft_ms=(
            f"Pada {y}, pekerjaan yang diunjurkan mempunyai lebihan ialah {surplus_items}. "
            f"Namun, dalam set 10 pekerjaan fokus yang sama, {len(deficits)} pekerjaan masih mengalami defisit. "
            f"Oleh itu, lebihan keseluruhan perlu dibaca bersama jurang pada tahap pekerjaan dan tidak wajar ditafsir sebagai ketiadaan masalah bakat E&E."
        )
        mode_hint='analytical'
    elif job_hit:
        code,j=job_hit; sj=val_for(j,'supply',y); dj=val_for(j,'demand',y); gj=sj-dj
        status_ms='lebihan' if gj>=0 else 'defisit'
        draft_ms=(
            f"Bagi {JOB_MS.get(code,j['name'])} pada {y}, bekalan diunjurkan sekitar {sj:,.0f} berbanding permintaan {dj:,.0f}, menghasilkan {status_ms} sekitar {abs(gj):,.0f}. "
            f"Angka ini ialah isyarat pada tahap pekerjaan; ia perlu dibaca bersama trend industri dan bukti pasaran kerja lain sebelum digunakan sebagai keputusan dasar muktamad."
        )
        mode_hint='analytical' if is_analytical(question) else 'direct'
    else:
        draft_ms=(
            f"Bagi 10 pekerjaan fokus E&E pada {y}, jumlah bekalan diunjurkan sekitar {ts:,.0f} berbanding permintaan {td:,.0f}, iaitu lebihan agregat sekitar {ts-td:,.0f}. "
            f"Namun, {len(deficits)} daripada {len(rows)} pekerjaan masih menunjukkan defisit. "
            f"Ini bermaksud gambaran agregat sahaja boleh menyembunyikan kekurangan pada pekerjaan tertentu."
        )
        mode_hint='analytical'
    return {'text':'\n'.join(lines),'sources':[source('Dataset Analitik Permintaan dan Penawaran Bakat E&E','E&E Supply & Demand','ee')],
            'topic':'supply','draft_ms':draft_ms,'mode_hint':mode_hint}


def _foresight_pack(question: str):
    q=norm(question)
    if not (any(k in q for k in ['foresight','stem skill','skill area','kemahiran stem','delphi','future stem']) or ('masa hadapan' in q and 'stem' in q)):
        return None
    lines=[
        'FORESIGHT STRUCTURED ANCHORS',
        'Horizon: 2025–2040.',
        'Ten STEM Skill Areas: Artificial Intelligence and Data Technologies; Computational and Physical Sciences; Digital Security and Cyber Defence; Energy and Engineering Infrastructure; Environmental and Sustainability; Food Security and Agricultural Systems; Healthcare and Biomedical Sciences; Materials Science and Advanced Manufacturing; Smart Systems and Digital Transformation; Strategic Planning and Risk Management.',
        'The report prioritises 40 STEM skills using an attractiveness–feasibility lens; 18 additional skills are placed on a watchlist for continued scanning/evidence gathering.',
        'Methodology combines horizon scanning, stakeholder engagement, technology assessment and a two-round Delphi.',
        'High-priority backbone in the executive summary includes AI and Data Technologies; Smart Systems and Digital Transformation; Digital Security and Cyber Defence; Environmental and Sustainability; Computational and Physical Sciences; Energy and Engineering Infrastructure; Strategic Planning and Risk Management.'
    ]
    draft_ms=(
        'Foresight STEM 2025–2040 menunjukkan bahawa keperluan bakat masa hadapan merentas 10 bidang kemahiran dan tidak tertumpu pada satu teknologi sahaja. '
        'Laporan mengutamakan 40 kemahiran STEM menggunakan lensa daya tarikan dan kebolehlaksanaan, dengan 18 lagi kemahiran dalam senarai pantauan. '
        'Antara bidang teras ialah AI dan teknologi data, sistem pintar dan transformasi digital, keselamatan siber, kelestarian, sains pengkomputeran dan fizikal serta infrastruktur tenaga dan kejuruteraan. '
        'Implikasinya ialah perancangan bakat perlu bersifat dinamik dan dikemas kini secara berkala apabila keperluan teknologi berubah.'
    )
    return {'text':'\n'.join(lines),'sources':[foresight_source(11),foresight_source(12),foresight_source(13)],
            'topic':'foresight','draft_ms':draft_ms,'mode_hint':'analytical'}



def _pipeline_pack(question: str):
    q=norm(question)
    broad = (
        any(k in q for k in ['pipeline','rantaian bakat','talent pipeline'])
        or ('stem' in q and any(k in q for k in ['risiko utama','main risk','bakat negara','nasional','negara']))
    )
    if not broad:
        return None

    # School-stage signals: use candidates sitting selected STEM subjects, not enrolment.
    subject_lines=[]
    for term in ['matematik','fizik','kimia','biologi']:
        hit=spm_subject(term)
        if not hit:
            continue
        _,obj=hit; series=obj.get('series',{})
        if '2018' not in series or '2025' not in series:
            continue
        a,b=series['2018'],series['2025']
        cand0,cand1=a.get('candidates'),b.get('candidates')
        gp0,gp1=a.get('gpmp'),b.get('gpmp')
        pct=((cand1-cand0)/cand0*100.0) if cand0 else 0.0
        subject_lines.append(
            f"{obj['name']}: candidates sitting subject {cand0:,.0f}→{cand1:,.0f} ({pct:+.1f}%); GPMP {gp0:.2f}→{gp1:.2f} (lower is better)."
        )

    # Graduate mismatch signal.
    overall_ap=MIS['overall']['all']['ap']
    manu_ap=MIS['manufacturing']['all']['ap']

    # E&E occupation-level supply-demand signal.
    ts=td=0.0; deficits=[]
    for code,j in SUP['jobs'].items():
        sv=val_for(j,'supply',2040); dv=val_for(j,'demand',2040)
        if sv is None or dv is None:
            continue
        ts+=sv; td+=dv
        if sv-dv < 0:
            deficits.append((code,j['name'],sv-dv))
    deficit_names=', '.join(JOB_MS.get(code,name) for code,name,_ in deficits)

    lines=[
        'CROSS-SOURCE STEM TALENT PIPELINE EVIDENCE',
        'Scope note: this is a synthesis of connected indicators, not proof of a single end-to-end linked individual-level pipeline.',
        'School-stage signals (SPM; number of candidates sitting the subject, not enrolment):',
        *subject_lines,
        f'Graduate mismatch: any-mismatch rate {overall_ap:.1f}% overall; {manu_ap:.1f}% in manufacturing.',
        f'E&E 2040, 10 focus occupations: aggregate supply {ts:,.0f} versus demand {td:,.0f}, but {len(deficits)} of 10 occupations remain in deficit: {deficit_names}.',
        'Foresight 2025–2040: 40 priority STEM skills across 10 skill areas, with 18 additional skills on a watchlist, indicating that skill requirements continue to evolve.',
        'INTERPRETATION GUARDRAIL: Do not describe the evidence as a proven national shortage of STEM talent. The connected evidence instead supports a structural-risk framing: participation, matching, occupation-specific gaps and changing skill requirements may move in different directions.'
    ]
    draft_ms=(
        f"Risiko utama rantaian bakat STEM bukan semata-mata kekurangan jumlah bakat, tetapi ketidakselarasan antara penyertaan, graduan, pekerjaan dan perubahan kemahiran. "
        f"Data SPM menunjukkan perubahan penyertaan dan prestasi yang berbeza mengikut mata pelajaran; kadar ketidaksepadanan graduan keseluruhan ialah {overall_ap:.1f}% dan {manu_ap:.1f}% dalam pembuatan. "
        f"Bagi E&E pada 2040, bekalan agregat melebihi permintaan, tetapi {len(deficits)} daripada 10 pekerjaan fokus masih defisit. "
        f"Pada masa yang sama, Foresight mengenal pasti 40 kemahiran keutamaan dan 18 kemahiran dalam senarai pantauan. "
        f"Isyarat keseluruhannya ialah isu bakat perlu dilihat sebagai masalah penyelarasan sepanjang rantaian, bukan satu angka kekurangan atau lebihan nasional."
    )
    return {
        'text':'\n'.join(lines),
        'sources':[
            source('Dataset Analitik Mata Pelajaran SPM','SPM Intelligence','spm'),
            source('Dataset Analitik Ketidaksepadanan Graduan','Graduate Mismatch','ee'),
            source('Dataset Analitik Permintaan dan Penawaran Bakat E&E','E&E Supply & Demand','ee'),
            foresight_source(11),
        ],
        'topic':'pipeline','draft_ms':draft_ms,'mode_hint':'analytical'
    }

def build_evidence_pack(question: str, context=None):
    """Return a deterministic evidence pack for LLM synthesis.

    Explicit question content takes priority over the dashboard tab currently open.
    Dashboard context is used only when the question itself is genuinely ambiguous.
    """
    pipeline=_pipeline_pack(question)
    if pipeline:
        packs=[pipeline]
    else:
        packs=[]
        # An explicit SPM subject/national question must not inherit E&E evidence merely
        # because the user happens to have an E&E dashboard tab open.
        spm_pack=_spm_subject_pack(question)
        if spm_pack:
            packs.append(spm_pack)
            if (p:=_mismatch_pack(question,None)): packs.append(p)
            if (p:=_supply_pack(question,None)): packs.append(p)
            if (p:=_foresight_pack(question)): packs.append(p)
        else:
            national=_spm_national_pack(question)
            if national:
                packs.append(national)
                if (p:=_mismatch_pack(question,None)): packs.append(p)
                if (p:=_supply_pack(question,None)): packs.append(p)
                if (p:=_foresight_pack(question)): packs.append(p)
            else:
                # Only here may the current dashboard context help resolve an otherwise
                # ambiguous E&E question.
                if (p:=_mismatch_pack(question,context)): packs.append(p)
                if (p:=_supply_pack(question,context)): packs.append(p)
                if (p:=_foresight_pack(question)): packs.append(p)
    if not packs:
        return {'text':'','sources':[],'topics':[]}
    text='\n\n---\n\n'.join(p['text'] for p in packs)
    sources=[]; seen=set()
    for p in packs:
        for s in p['sources']:
            k=(s.get('title'),s.get('page'),s.get('view'))
            if k not in seen:
                seen.add(k); sources.append(s)
    drafts=[p.get('draft_ms','') for p in packs if p.get('draft_ms')]
    mode_hint='analytical' if any(p.get('mode_hint')=='analytical' for p in packs) else 'direct'
    return {'text':text,'sources':sources,'topics':[p['topic'] for p in packs],
            'draft_ms':' '.join(drafts).strip(),'mode_hint':mode_hint}

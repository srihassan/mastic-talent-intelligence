from __future__ import annotations
import json, re, difflib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'

def load(name): return json.loads((DATA/name).read_text(encoding='utf-8'))
SPM=load('spm_subjects.json'); SPM_CORE={int(k):v for k,v in load('spm_core.json').items()}
SUP=load('supply_demand.json'); MIS=load('graduate_mismatch.json')

def norm(s): return re.sub(r'[^a-z0-9]+',' ',str(s).lower()).strip()
def years(q): return [int(x) for x in re.findall(r'\b20\d{2}\b',q)]
def source(title, module, view=None, note=None):
    d={'title':title,'module':module,'kind':'data'}
    if view: d['view']=view
    if note: d['note']=note
    return d

def fmt(x,dec=1):
    if x is None:return '—'
    if isinstance(x,int): return f'{x:,}'
    if abs(float(x)-round(float(x)))<1e-9:return f'{int(round(float(x))):,}'
    return f'{float(x):,.{dec}f}'

def spm_subject(q):
    nq=norm(q)

    # Prefer the longest exact subject name so "Matematik Tambahan"
    # is not accidentally matched as "Matematik".
    exact=[]
    for code,obj in SPM.items():
        name=norm(obj.get('name',''))
        if name and name in nq:
            exact.append((len(name),code,obj))
    if exact:
        _,code,obj=max(exact,key=lambda x:x[0])
        return code,obj

    # aliases used in management demo
    aliases={
        'fizik':'physics','physics':'fizik','kimia':'chemistry','chemistry':'kimia',
        'biologi':'biology','biology':'biologi','matematik tambahan':'additional mathematics',
        'additional mathematics':'matematik tambahan','add maths':'additional mathematics',
        'sains komputer':'computer science','computer science':'sains komputer'
    }
    for a in sorted(aliases,key=len,reverse=True):
        if a in nq:
            for code,obj in SPM.items():
                n=norm(obj.get('name',''))
                if a in n or aliases[a] in n:
                    return code,obj

    # Conservative fuzzy fallback.
    best=None
    for code,obj in SPM.items():
        name=norm(obj.get('name',''))
        ratio=difflib.SequenceMatcher(None,name,nq).ratio()
        if best is None or ratio>best[0]:
            best=(ratio,code,obj)
    return (best[1],best[2]) if best and best[0]>=0.58 else None


def _spm_subject_trend_answer(obj, lang='ms'):
    """Deterministic trend summary from structured subject data only."""
    series=obj.get('series',{})
    ys=sorted(map(int,series.keys()))
    if not ys:
        return None
    first,last=ys[0],ys[-1]
    d0,dl=series[str(first)],series[str(last)]
    best=min(ys,key=lambda y: float(series[str(y)].get('gpmp',999)))
    worst=max(ys,key=lambda y: float(series[str(y)].get('gpmp',-999)))
    db,dw=series[str(best)],series[str(worst)]

    # Explicitly encode the GPMP direction rule: lower = better.
    delta=float(dl['gpmp'])-float(d0['gpmp'])
    if abs(delta)<0.005:
        endpoint_ms=f"GPMP {last} kembali ke paras {first}, iaitu {dl['gpmp']:.2f}."
        endpoint_en=f"The {last} GPMP returned to the {first} level at {dl['gpmp']:.2f}."
    elif delta<0:
        endpoint_ms=f"GPMP bertambah baik daripada {d0['gpmp']:.2f} ({first}) kepada {dl['gpmp']:.2f} ({last}); nilai lebih rendah adalah lebih baik."
        endpoint_en=f"GPMP improved from {d0['gpmp']:.2f} ({first}) to {dl['gpmp']:.2f} ({last}); lower is better."
    else:
        endpoint_ms=f"GPMP merosot daripada {d0['gpmp']:.2f} ({first}) kepada {dl['gpmp']:.2f} ({last}); nilai lebih rendah adalah lebih baik."
        endpoint_en=f"GPMP deteriorated from {d0['gpmp']:.2f} ({first}) to {dl['gpmp']:.2f} ({last}); lower is better."

    if lang=='en':
        return (
            f"{obj['name']} SPM performance, {first}–{last}: {endpoint_en} "
            f"The weakest GPMP in the series was {dw['gpmp']:.2f} in {worst}, while the best was {db['gpmp']:.2f} in {best}. "
            f"The pass rate changed from {d0['passrate']:.1f}% to {dl['passrate']:.1f}%, credit-or-better from "
            f"{d0['credit_plus_pct']:.1f}% to {dl['credit_plus_pct']:.1f}%, and the fail rate from {d0['fail']:.1f}% to {dl['fail']:.1f}%. "
            f"Overall, the GPMP endpoint has recovered to the {first} level, but the broader outcome indicators should be read separately rather than treating GPMP alone as the full picture."
        )
    return (
        f"Prestasi SPM bagi {obj['name']}, {first}–{last}: {endpoint_ms} "
        f"GPMP paling lemah dalam siri ini ialah {dw['gpmp']:.2f} pada {worst}, manakala yang terbaik ialah {db['gpmp']:.2f} pada {best}. "
        f"Kadar lulus berubah daripada {d0['passrate']:.1f}% kepada {dl['passrate']:.1f}%, kadar sekurang-kurangnya kepujian daripada "
        f"{d0['credit_plus_pct']:.1f}% kepada {dl['credit_plus_pct']:.1f}%, dan kadar gagal daripada {d0['fail']:.1f}% kepada {dl['fail']:.1f}%. "
        f"Secara keseluruhan, GPMP pada {last} telah kembali ke paras {first}, tetapi indikator hasil yang lain perlu dibaca berasingan dan tidak wajar disimpulkan daripada GPMP sahaja."
    )


def answer_spm(q,lang='ms'):
    nq=norm(q); ys=[y for y in years(q) if 2018<=y<=2025]
    subj=spm_subject(q)
    if subj:
        _,obj=subj; series=obj.get('series',{})
        if not series:return None

        # Trend/performance evidence is calculated deterministically from the
        # structured dataset before Ollama synthesis, reducing numeric drift.
        trend_terms=['prestasi','performance','trend','aliran','corak','pattern','perkembangan','analisis','analysis','ringkasan','summary','overview']
        if any(t in nq for t in trend_terms) and not (len(ys)==1 and not any(t in nq for t in ['trend','aliran','corak','pattern'])):
            txt=_spm_subject_trend_answer(obj,lang)
            return {'answer':txt,'sources':[source('SPM subject-level analytical dataset','SPM Intelligence','spm')],'route':'structured:spm-trend','confidence':'high'}

        y=ys[-1] if ys else max(map(int,series.keys()))
        d=series.get(str(y));
        if not d:return None
        metric='gpmp'
        if re.search(r'kadar lulus|pass rate|\blulus\b',nq): metric='passrate'
        elif re.search(r'gagal|fail',nq): metric='fail'
        elif re.search(r'kepujian|credit',nq): metric='credit_plus_pct'
        elif re.search(r'calon|candidate|penyertaan|participation',nq): metric='candidates'
        elif re.search(r'cemerlang|excellent',nq): metric='excellent'
        labels={'gpmp':'GPMP','passrate':'Kadar lulus','fail':'Kadar gagal','credit_plus_pct':'Sekurang-kurangnya kepujian','candidates':'Bilangan calon','excellent':'Cemerlang'}
        v=d.get(metric); suffix='%' if metric in {'passrate','fail','credit_plus_pct','excellent'} else ''
        decimals=2 if metric=='gpmp' else 1
        txt=f"{obj['name']}, SPM {y}: {labels[metric]} = {fmt(v,decimals)}{suffix}."
        return {'answer':txt,'sources':[source('SPM subject-level analytical dataset','SPM Intelligence','spm')],'route':'structured:spm','confidence':'high'}
    metric=None
    if re.search(r'calon.*daftar|berdaftar|registered',nq): metric='registered'
    elif re.search(r'gpk|gpn|gred purata',nq): metric='average'
    elif re.search(r'sijil|certificate|pensijilan',nq): metric='cert'
    elif re.search(r'jurang|bandar|luar bandar|locality',nq): metric='gap'
    if not metric:return None
    if not ys: ys=[2025]
    if len(ys)>=2 or re.search(r'trend|aliran|hingga|banding|compare',nq):
        a,b=min(ys),max(ys); yrs=[y for y in range(a,b+1) if y in SPM_CORE]
    else: yrs=ys
    labs={'registered':'Calon berdaftar','average':'GPN/GPK','cert':'Layak dianugerahkan sijil','gap':'Jurang bandar-luar bandar'}
    rows=[]
    for y in yrs:
        v=SPM_CORE[y][metric]; suff='%' if metric=='cert' else ''
        rows.append(f'{y}: {fmt(v,2 if metric in {"average","gap"} else 0)}{suff}')
    return {'answer':f"{labs[metric]} - "+' · '.join(rows), 'sources':[source('SPM national analytical series','SPM Intelligence','spm')], 'route':'structured:spm','confidence':'high'}

def find_job(q):
    nq=norm(q); best=None
    for code,j in SUP['jobs'].items():
        name=norm(j['name'])
        if code in nq or name in nq:return code,j
        # Malay/common tokens
        tokens=[t for t in name.split() if len(t)>4]
        overlap=sum(t in nq for t in tokens)
        if overlap and (best is None or overlap>best[0]):best=(overlap,code,j)
    aliases={'jurutera elektrik':'2151','jurutera elektronik':'2152','pengurus r d':'1223','pengurus pembuatan':'1321','jurutera industri':'2141','juruteknik kejuruteraan elektrik':'3113','juruteknik kejuruteraan elektronik':'3114','penyelia pembuatan':'3122','mekanik elektrik':'7412','mekanik elektronik':'7421'}
    for a,c in aliases.items():
        if a in nq:return c,SUP['jobs'][c]
    return (best[1],best[2]) if best else None

def val_for(job,key,year):
    idx=SUP['years'].index(year)
    actual=job.get(key+'_actual',[None]*len(SUP['years']))[idx]
    fc=job.get(key+'_forecast',[None]*len(SUP['years']))[idx]
    return actual if actual is not None else fc

def answer_supply(q,lang='ms'):
    nq=norm(q)
    keywords=['supply','demand','bekalan','permintaan','defisit','surplus','lebihan','kekurangan','pekerjaan','2040']
    if not any(k in nq for k in keywords):return None
    y=(years(q) or [2040])[-1]
    if y not in SUP['years']:return None
    hit=find_job(q)
    if hit:
        code,j=hit; s=val_for(j,'supply',y); d=val_for(j,'demand',y); gap=s-d if s is not None and d is not None else None
        status='lebihan' if gap is not None and gap>=0 else 'defisit'
        ans=f"{j['name']} (MASCO {code}), {y}: bekalan {fmt(s)}, permintaan {fmt(d)}, {status} {fmt(abs(gap))}."
        return {'answer':ans,'sources':[source('E&E Supply & Demand analytical dataset','E&E Supply & Demand','ee')],'route':'structured:supply','confidence':'high'}
    rows=[]; total_s=total_d=0
    for code,j in SUP['jobs'].items():
        s=val_for(j,'supply',y); d=val_for(j,'demand',y)
        if s is None or d is None: continue
        total_s+=s; total_d+=d; rows.append((s-d,code,j['name'],s,d))
    if re.search(r'defisit|kekurangan',nq):
        bad=sorted([r for r in rows if r[0]<0])
        names=', '.join(f"{name} ({fmt(abs(g))})" for g,_,name,_,_ in bad)
        ans=f"Pekerjaan yang menunjukkan defisit pada {y}: {names}."
    elif re.search(r'surplus|lebihan',nq) and re.search(r'pekerjaan|job|mana|which',nq):
        good=sorted([r for r in rows if r[0]>=0], reverse=True)
        names=', '.join(f"{name} ({fmt(g)})" for g,_,name,_,_ in good)
        ans=f"Pekerjaan yang menunjukkan lebihan pada {y}: {names}."
    else:
        gap=total_s-total_d; status='lebihan' if gap>=0 else 'defisit'
        ans=f"Agregat 10 pekerjaan fokus E&E pada {y}: bekalan {fmt(total_s)}, permintaan {fmt(total_d)}, {status} {fmt(abs(gap))}."
    return {'answer':ans,'sources':[source('E&E Supply & Demand analytical dataset','E&E Supply & Demand','ee')],'route':'structured:supply','confidence':'high'}

def answer_mismatch(q,lang='ms'):
    nq=norm(q)
    if not any(k in nq for k in ['mismatch','ketidaksepadanan','tak sepadan','tidak sepadan','menegak','mendatar','vertical','horizontal','tvet']):return None
    scope='manufacturing' if any(k in nq for k in ['pembuatan','manufacturing']) else 'overall'
    group='tvet' if 'tvet' in nq else ('ipt' if any(k in nq for k in ['ipt','bukan tvet','non tvet','universiti']) else 'all')
    metric='ap'
    label='Ketidaksepadanan keseluruhan'
    if any(k in nq for k in ['menegak','vertical']):metric='vp';label='Ketidaksepadanan menegak'
    elif any(k in nq for k in ['mendatar','horizontal']):metric='hp';label='Ketidaksepadanan mendatar'
    elif any(k in nq for k in ['kedua dua','dual','both']):metric='dp';label='Kedua-dua ketidaksepadanan'
    d=MIS[scope][group]; value=d.get(metric)
    scope_label='pembuatan' if scope=='manufacturing' else 'semua sektor'
    group_label={'all':'semua graduan','tvet':'TVET','ipt':'IPT / bukan TVET'}[group]
    ans=f"{label} bagi {group_label}, {scope_label}: {fmt(value)}%."
    return {'answer':ans,'sources':[source('Graduate Mismatch analytical dataset','Graduate Mismatch','ee')],'route':'structured:mismatch','confidence':'high'}



def foresight_source(page, note=None):
    d={'title':'Future of STEM Talent in Malaysia: A Delphi Approach','module':'Foresight Skill Matching','kind':'document','page':page,'url':f'/documents/STI_Foresight_Report_2025_2040.pdf#page={page}'}
    if note:d['note']=note
    return d

def answer_foresight(q,lang='ms'):
    nq=norm(q)
    if not any(k in nq for k in ['foresight','stem skill','skill area','kemahiran stem','delphi','future stem']) and not ('masa hadapan' in nq and 'stem' in nq):
        return None
    areas=['Artificial Intelligence and Data Technologies','Computational and Physical Sciences','Digital Security and Cyber Defence','Energy and Engineering Infrastructure','Environmental and Sustainability','Food Security and Agricultural Systems','Healthcare and Biomedical Sciences','Materials Science and Advanced Manufacturing','Smart Systems and Digital Transformation','Strategic Planning and Risk Management']
    if any(k in nq for k in ['10 stem','10 skill','skill areas','bidang stem','bidang kemahiran','10 bidang']):
        ans='10 STEM Skill Areas yang dikenal pasti ialah: '+ '; '.join(f'{i+1}. {x}' for i,x in enumerate(areas))+'.'
        return {'answer':ans,'sources':[foresight_source(11)],'route':'structured:foresight','confidence':'high'}
    if 'delphi' in nq or any(k in nq for k in ['metodologi','methodology','kaedah kajian','approach']):
        ans='Kajian menggabungkan horizon scanning, stakeholder engagements, technology assessment dan Delphi dua pusingan. Proses bergerak melalui lima peringkat dan menghasilkan pemeringkatan konsensus berdasarkan dua kriteria utama: attractiveness untuk penciptaan nilai negara dan feasibility ekosistem semasa.'
        return {'answer':ans,'sources':[foresight_source(11),foresight_source(23)],'route':'structured:foresight','confidence':'high'}
    if any(k in nq for k in ['berapa kemahiran','40','prioritised','prioritized','diprioritikan','watchlist','18']):
        ans='Laporan memprioritikan 40 STEM skills ke dalam lima kumpulan berasaskan attractiveness-feasibility. Sebanyak 18 skills tidak mencapai threshold dan diletakkan untuk continued scanning/evidence gathering.'
        return {'answer':ans,'sources':[foresight_source(12),foresight_source(13)],'route':'structured:foresight','confidence':'high'}
    if any(k in nq for k in ['backbone','high priority','keutamaan tinggi','priority areas']):
        backbone=['Artificial Intelligence and Data Technologies','Smart Systems and Digital Transformation','Digital Security and Cyber Defence','Environmental and Sustainability','Computational and Physical Sciences','Energy and Engineering Infrastructure','Strategic Planning and Risk Management']
        ans='High Priority Backbone STEM Skill Areas yang ditunjukkan dalam ringkasan eksekutif ialah: '+ '; '.join(backbone)+'.'
        return {'answer':ans,'sources':[foresight_source(11),foresight_source(12)],'route':'structured:foresight','confidence':'high'}
    return None

def answer_structured(q,lang='ms',context=None):
    nq=norm(q)
    f=answer_foresight(q,lang)
    if f:return f
    # Explicit topic routing first.
    if any(k in nq for k in ['mismatch','ketidaksepadanan','tak sepadan','tidak sepadan','menegak','mendatar']):
        return answer_mismatch(q,lang)
    if any(k in nq for k in ['supply','demand','bekalan','permintaan','defisit','surplus','lebihan','kekurangan']) or (context or {}).get('ee_tab')=='supply':
        a=answer_supply(q,lang)
        if a:return a
    a=answer_spm(q,lang)
    if a:return a
    if (context or {}).get('ee_tab')=='mismatch':
        return answer_mismatch(q,lang)
    return None

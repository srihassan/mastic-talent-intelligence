from __future__ import annotations
import json, re, hashlib
from pathlib import Path
import fitz

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / 'documents'
INDEX = ROOT / 'index'
INDEX.mkdir(exist_ok=True)
CHUNKS_PATH = INDEX / 'chunks.json'
META_PATH = ROOT / 'data' / 'document_metadata.json'


def clean_text(text: str) -> str:
    text = text.replace('\x00', ' ')
    text = re.sub(r'[ \t]+', ' ', text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def chunk_page(text: str, target=1200, overlap=180):
    text = clean_text(text)
    if not text:
        return []
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    chunks, buf = [], ''
    for p in paras:
        if len(buf) + len(p) + 2 <= target:
            buf = (buf + '\n\n' + p).strip()
        else:
            if buf:
                chunks.append(buf)
            if len(p) <= target:
                buf = p
            else:
                start = 0
                while start < len(p):
                    end = min(len(p), start + target)
                    chunks.append(p[start:end])
                    if end == len(p):
                        break
                    start = max(end - overlap, start + 1)
                buf = ''
    if buf:
        chunks.append(buf)
    return chunks


def infer_meta(pdf: Path):
    n = pdf.name
    ym = re.search(r'SPM[_\s-]*(20\d{2})', n, re.I)
    if ym:
        y = ym.group(1)
        return {'module':'SPM Intelligence','type':'Official Report','title':f'Laporan Analisis Keputusan SPM {y}','period':y,'owner':'KPM'}
    if 'foresight' in n.lower():
        return {'module':'Foresight Skill Matching','type':'STI Foresight Report','title':'Future of STEM Talent in Malaysia: A Delphi Approach','period':'2025-2040','owner':'MOSTI / MIGHT'}
    return {'module':'Other','type':'Source Document','title':pdf.stem.replace('_',' '),'period':'','owner':''}


def load_meta():
    if META_PATH.exists():
        try: return json.loads(META_PATH.read_text(encoding='utf-8'))
        except Exception: pass
    return {}


def save_meta(meta):
    META_PATH.parent.mkdir(exist_ok=True)
    META_PATH.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')


def build_index():
    meta_db = load_meta()
    chunks = []
    docs_summary = []
    for pdf in sorted(DOCS.glob('*.pdf')):
        doc_meta = dict(infer_meta(pdf))
        doc_meta.update(meta_db.get(pdf.name, {}))
        file_hash = hashlib.sha1(pdf.read_bytes()).hexdigest()[:12]
        pages_with_text = 0
        doc = fitz.open(pdf)
        for pno, page in enumerate(doc, start=1):
            text = clean_text(page.get_text('text'))
            if len(text) >= 30:
                pages_with_text += 1
            for ci, part in enumerate(chunk_page(text)):
                chunks.append({
                    'id': f'{file_hash}-{pno}-{ci}',
                    'file': pdf.name,
                    'title': doc_meta.get('title', pdf.stem),
                    'module': doc_meta.get('module','Other'),
                    'type': doc_meta.get('type','Source Document'),
                    'period': doc_meta.get('period',''),
                    'owner': doc_meta.get('owner',''),
                    'page': pno,
                    'text': part,
                    'url': f'/documents/{pdf.name}#page={pno}',
                })
        docs_summary.append({'file':pdf.name,'pages':len(doc),'pages_with_text':pages_with_text,'chunks':sum(1 for c in chunks if c['file']==pdf.name)})
        doc.close()
        # Make sure every bundled doc is known to metadata store.
        meta_db.setdefault(pdf.name, doc_meta)
    CHUNKS_PATH.write_text(json.dumps(chunks, ensure_ascii=False), encoding='utf-8')
    save_meta(meta_db)
    print(f'Indexed {len(docs_summary)} PDFs into {len(chunks)} chunks')
    for d in docs_summary:
        print(f" - {d['file']}: {d['pages']} pages, {d['chunks']} chunks")
    return chunks

if __name__ == '__main__':
    build_index()
